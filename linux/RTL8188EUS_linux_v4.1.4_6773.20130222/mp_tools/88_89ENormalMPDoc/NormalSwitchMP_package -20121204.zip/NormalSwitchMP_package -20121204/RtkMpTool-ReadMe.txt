RtkMpTool.apk need to use "rtwpriv", 
please frist to prepare build the rtwpriv and push to Android system.

Installation steps:
1. adb push rtwpriv /system/bin/
2. adb shell chmod 755 /system/bin/rtwpriv 
3. adb push 8723as.ko /system/sps/rtl8723as/ko/8723as.ko
4. adb install RtkMpTool.apk or adb install RtkWiFiTest.apk

P.S. 
1. RtkMpTool.apk only supports the MP test functions.
After installed, you will see a "Realtek MP Tool" App on the phone.

2. RtkWiFiTest.apk supports both MP test and CTA test functions.
After installed, you will see a "WiFi Test" App on the phone.